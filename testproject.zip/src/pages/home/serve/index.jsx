import React from 'react';

export default function Serve(){
    return(
        <div>Serve</div>
    )
}
