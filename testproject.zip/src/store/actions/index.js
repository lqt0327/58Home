import * as historykeywords from './hkaction';

export default {
    hk:historykeywords,
}