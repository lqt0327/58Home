function addHistoryKeywords(data) {
    return {
        type:"addHK",
        data
    }
}

export {
    addHistoryKeywords
}